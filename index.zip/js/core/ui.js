const confirmModal = document.getElementById('confirmModal')

const confirmMessage = document.getElementById('confirmMessage')

const confirmOk = document.getElementById('confirmOk')

const confirmCancel = document.getElementById('confirmCancel')

function showToast(message, type = 'success') {
  const toast = document.getElementById('toast')

  toast.className = `toast ${type}`

  toast.textContent = message

  requestAnimationFrame(() => {
    toast.classList.add('show')
  })

  clearTimeout(showToast.timer)

  showToast.timer = setTimeout(() => {
    toast.classList.remove('show')
  }, 3000)
}

function showConfirm(message) {
  return new Promise((resolve) => {
    confirmMessage.textContent = message

    confirmModal.classList.add('show')

    const close = (result) => {
      confirmModal.classList.remove('show')

      confirmOk.onclick = null
      confirmCancel.onclick = null

      resolve(result)
    }

    confirmOk.onclick = () => close(true)

    confirmCancel.onclick = () => close(false)
  })
}
